using LucasAguiar.Configs;

namespace LucasAguiar.Models
{
    public class PlanoDAO
    {
        private readonly Conexao _conexao;

        public PlanoDAO(Conexao conexao)
        {
            _conexao = conexao;
        }

        // Inserir um novo plano
        public void Inserir(Plano plano)
        {
            try
            {
                var comando = _conexao.CreateCommand(@"INSERT INTO plano (nome_plan, descricao_plan, valor_plan)
            VALUES (@_nome, @_descricao, @_valor)");

                comando.Parameters.AddWithValue("@_nome", plano.NomePlano);
                comando.Parameters.AddWithValue("@_descricao", plano.Descricao);
                comando.Parameters.AddWithValue("@_valor", plano.Valor);

                comando.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw new Exception("Erro ao inserir plano: " + ex.Message);
            }
        }

        // Listar todos os planos
        public List<Plano> ListarTodos()
        {
            var lista = new List<Plano>();

            try
            {
                var comando = _conexao.CreateCommand("SELECT * FROM plano");
                var leitor = comando.ExecuteReader();

                while (leitor.Read())
                {
                    var plano = new Plano
                    {
                        IdPlano = leitor.GetInt32("id_plan"),
                        NomePlano = leitor.IsDBNull(leitor.GetOrdinal("nome_plan")) ? "" : leitor.GetString("nome_plan"),
                        Descricao = leitor.IsDBNull(leitor.GetOrdinal("descricao_plan")) ? "" : leitor.GetString("descricao_plan"),
                        Valor = leitor.IsDBNull(leitor.GetOrdinal("valor_plan")) ? 0f : leitor.GetFloat("valor_plan")
                    };

                    lista.Add(plano);
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Erro ao listar planos: " + ex.Message);
            }

            return lista;
        }

        // Atualizar um plano existente
        public void Atualizar(Plano plano)
        {
            try
            {
                var comando = _conexao.CreateCommand(
                    @"UPDATE plano 
                    SET nome_plan = @_nome, descricao_plan = @_descricao, valor_plan = @_valor 
                    WHERE id_plan = @_id");

                comando.Parameters.AddWithValue("@_nome", plano.NomePlano);
                comando.Parameters.AddWithValue("@_descricao", plano.Descricao);
                comando.Parameters.AddWithValue("@_valor", plano.Valor);
                comando.Parameters.AddWithValue("@_id", plano.IdPlano);

                comando.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw new Exception("Erro ao atualizar plano: " + ex.Message);
            }
        }

        // Buscar plano por Id (opcional, útil para edição/exclusão)
        public Plano? BuscarPorId(int id)
        {
            try
            {
                var comando = _conexao.CreateCommand("SELECT * FROM plano WHERE id_plan = @_id");
                comando.Parameters.AddWithValue("@_id", id);

                var leitor = comando.ExecuteReader();

                if (leitor.Read())
                {
                    return new Plano
                    {
                        IdPlano = leitor.GetInt32("id_plan"),
                        NomePlano = leitor.IsDBNull(leitor.GetOrdinal("nome_plan")) ? "" : leitor.GetString("nome_plan"),
                        Descricao = leitor.IsDBNull(leitor.GetOrdinal("descricao_plan")) ? "" : leitor.GetString("descricao_plan"),
                        Valor = leitor.IsDBNull(leitor.GetOrdinal("valor_plan")) ? 0f : leitor.GetFloat("valor_plan")
                    };
                }

                return null;
            }
            catch (Exception ex)
            {
                throw new Exception("Erro ao buscar plano: " + ex.Message);
            }
        }

        // Excluir plano
        public void Excluir(int id)
        {
            try
            {
                var comando = _conexao.CreateCommand("DELETE FROM plano WHERE id_plan = @_id");
                comando.Parameters.AddWithValue("@_id", id);

                comando.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw new Exception("Erro ao excluir plano: " + ex.Message);
            }
        }
    }
}
