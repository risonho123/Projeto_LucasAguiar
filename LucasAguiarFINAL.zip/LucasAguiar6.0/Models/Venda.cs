namespace LucasAguiar.Models
{
    public class Venda
    {
        public int IdVend { get; set; }

        public float ValorVend { get; set; }

        public DateTime DataVend { get; set; }

        public int QuantidadeProdVend { get; set; }

        public int QuantidadeServVend { get; set; }

        public string? FormaPagamentoVend { get; set; }

        public float DescontoVend { get; set; }

        public int QuantParcelaVend { get; set; }

        public string? DescricaoVend { get; set; }

        public string? StatusVend { get; set; }

        public int IdServFk { get; set; }

        public int IdProdFk { get; set; }

        public int IdFunFk { get; set; }

        public int IdCliFk { get; set; }
    }
}
