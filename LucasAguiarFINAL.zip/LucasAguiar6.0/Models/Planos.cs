namespace LucasAguiar.Models
{
    public class Plano

    {
        public int IdPlano { get; set; }

        public string? NomePlano { get; set; }

        public string? Descricao { get; set; }

        public float? Valor { get; set; }
    }
}
