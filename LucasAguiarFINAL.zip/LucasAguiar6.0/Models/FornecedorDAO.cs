﻿using LucasAguiar.Configs;

namespace LucasAguiar.Models
{
    public class FornecedorDAO
    {
        private readonly Conexao _conexao;

        public FornecedorDAO(Conexao conexao)
        {
            _conexao = conexao;
        }

        public void Inserir(Fornecedor fornecedor)
        {
            try
            {
                var comando = _conexao.CreateCommand(@"INSERT INTO fornecedor 
                    (nome_forn, email_forn, telefone_forn, tipo_prod_forn)
                    VALUES (@_nome, @_email, @_telefone, @_tipo)");

                comando.Parameters.AddWithValue("@_nome", fornecedor.NomeFornecedor);
                comando.Parameters.AddWithValue("@_email", fornecedor.Email);
                comando.Parameters.AddWithValue("@_telefone", fornecedor.Telefone);
                comando.Parameters.AddWithValue("@_tipo", fornecedor.TipoProd);

                comando.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw new Exception("Erro ao inserir fornecedor: " + ex.Message);
            }
        }

        public Fornecedor? BuscarPorId(int id)
        {
            var comando = _conexao.CreateCommand(
                "SELECT * FROM fornecedor WHERE id_forn = @id;");
            comando.Parameters.AddWithValue("@id", id);

            var leitor = comando.ExecuteReader();

            if (leitor.Read())
            {
                var fornecedor = new Fornecedor
                {
                    IdFornecedor   = leitor.GetInt32("id_forn"),
                    NomeFornecedor = leitor.IsDBNull(leitor.GetOrdinal("nome_forn")) ? "" : leitor.GetString("nome_forn"),
                    Email          = leitor.IsDBNull(leitor.GetOrdinal("email_forn")) ? "" : leitor.GetString("email_forn"),
                    Telefone       = leitor.IsDBNull(leitor.GetOrdinal("telefone_forn")) ? "" : leitor.GetString("telefone_forn"),
                    TipoProd       = leitor.IsDBNull(leitor.GetOrdinal("tipo_prod_forn")) ? "" : leitor.GetString("tipo_prod_forn")
                };

                return fornecedor;
            }

            return null;
        }

        public void Atualizar(Fornecedor fornecedor)
        {
            try
            {
                var comando = _conexao.CreateCommand(@"UPDATE fornecedor SET nome_forn = @_nome, email_forn = @_email, telefone_forn = @_telefone,tipo_prod_forn = @_tipo WHERE id_forn = @_id;");
                comando.Parameters.AddWithValue("@_nome", fornecedor.NomeFornecedor);
                comando.Parameters.AddWithValue("@_email", fornecedor.Email);
                comando.Parameters.AddWithValue("@_telefone", fornecedor.Telefone);
                comando.Parameters.AddWithValue("@_tipo", fornecedor.TipoProd);
                comando.Parameters.AddWithValue("@_id", fornecedor.IdFornecedor);

                comando.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw new Exception("Erro ao atualizar fornecedor: " + ex.Message);
            }
        }

        public void Excluir(int id)
        {
            try
            {
                var comando = _conexao.CreateCommand(
                    "DELETE FROM fornecedor WHERE id_forn = @id;");
                comando.Parameters.AddWithValue("@id", id);

                comando.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw new Exception("Erro ao excluir fornecedor: " + ex.Message);
            }
        }

        public List<Fornecedor> ListarTodos()
        {
            var lista = new List<Fornecedor>();

            var comando = _conexao.CreateCommand("SELECT * FROM fornecedor");
            var leitor = comando.ExecuteReader();

            while (leitor.Read())
            {
                var fornecedor = new Fornecedor
                {
                    IdFornecedor   = leitor.GetInt32("id_forn"),
                    NomeFornecedor = leitor.IsDBNull(leitor.GetOrdinal("nome_forn")) ? "" : leitor.GetString("nome_forn"),
                    Email          = leitor.IsDBNull(leitor.GetOrdinal("email_forn")) ? "" : leitor.GetString("email_forn"),
                    Telefone       = leitor.IsDBNull(leitor.GetOrdinal("telefone_forn")) ? "" : leitor.GetString("telefone_forn"),
                    TipoProd       = leitor.IsDBNull(leitor.GetOrdinal("tipo_prod_forn")) ? "" : leitor.GetString("tipo_prod_forn")
                };

                lista.Add(fornecedor);
            }

            return lista;
        }
    }
}
