using LucasAguiar.Configs;
using MySqlConnector;
using AppWeb.Configs; // Presumindo que DAOHelper e Conexao estejam aqui
using System.Collections.Generic;

namespace LucasAguiar.Models
{
    public class ClienteDAO
    {
        private readonly Conexao _conexao;

        public ClienteDAO(Conexao conexao)
        {
            _conexao = conexao;
        }

        // --- INSERIR (CREATE) ---
        public void Inserir(Cliente cliente)
        {
            try
            {
                var comando = _conexao.CreateCommand(@"
                    INSERT INTO cliente (nome_cli, telefone_cli, cpf_cli, data_nasc_cli, rg_cli, estado_cli, cidade_cli, bairro_cli, rua_cli, numero_cli, id_plan_fk)
                    VALUES (@_nome, @_telefone, @_cpf, @_dataNasc, @_rg, @_estado, @_cidade, @_bairro, @_rua, @_numero, @_idPlano)
                ");

                comando.Parameters.AddWithValue("@_nome", cliente.NomeCliente);
                comando.Parameters.AddWithValue("@_telefone", cliente.Telefone);
                comando.Parameters.AddWithValue("@_cpf", cliente.CPF);
                comando.Parameters.AddWithValue("@_dataNasc", cliente.DataNascimento);
                comando.Parameters.AddWithValue("@_rg", cliente.RG);
                comando.Parameters.AddWithValue("@_estado", cliente.Estado);
                comando.Parameters.AddWithValue("@_cidade", cliente.Cidade);
                comando.Parameters.AddWithValue("@_bairro", cliente.Bairro);
                comando.Parameters.AddWithValue("@_rua", cliente.Rua);
                comando.Parameters.AddWithValue("@_numero", cliente.Numero);
                comando.Parameters.AddWithValue("@_idPlano", cliente.IdPlano);

                comando.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw new Exception("Erro ao inserir cliente: " + ex.Message);
            }
        }

        // --- BUSCAR POR ID (READ Single) ---
        public Cliente? BuscarPorId(int id)
        {
            var comando = _conexao.CreateCommand(@"
                SELECT * FROM cliente WHERE id_cli = @id;
            ");
            comando.Parameters.AddWithValue("@id", id);

            var leitor = comando.ExecuteReader();

            if (leitor.Read())
            {
                var cliente = new Cliente
                {
                    IdCliente = leitor.GetInt32("id_cli"),
                    NomeCliente = DAOHelper.GetString(leitor, "nome_cli"),
                    Telefone = DAOHelper.GetString(leitor, "telefone_cli"),
                    CPF = DAOHelper.GetString(leitor, "cpf_cli"),
                    RG = DAOHelper.GetString(leitor, "rg_cli"),
                    Estado = DAOHelper.GetString(leitor, "estado_cli"),
                    Cidade = DAOHelper.GetString(leitor, "cidade_cli"),
                    Bairro = DAOHelper.GetString(leitor, "bairro_cli"),
                    Rua = DAOHelper.GetString(leitor, "rua_cli"),
                    Numero = DAOHelper.GetString(leitor, "numero_cli"),
                    
                    DataNascimento = leitor.IsDBNull(leitor.GetOrdinal("data_nasc_cli")) ? null : leitor.GetDateTime("data_nasc_cli"),
                    
                    // Assumindo que id_plan_fk existe para mapeamento correto:
                    IdPlano = leitor.IsDBNull(leitor.GetOrdinal("id_plan_fk")) ? (int?)null : leitor.GetInt32("id_plan_fk")
                };

                return cliente;
            }
            else
            {
                return null;
            }
        }

        // --- ATUALIZAR (UPDATE) ---
        public void Atualizar(Cliente cliente)
        {
            try
            {
                var comando = _conexao.CreateCommand(@"
                    UPDATE cliente SET 
                        nome_cli = @_nome, 
                        telefone_cli = @_telefone, 
                        cpf_cli = @_cpf, 
                        data_nasc_cli = @_dataNasc, 
                        rg_cli = @_rg, 
                        estado_cli = @_estado, 
                        cidade_cli = @_cidade, 
                        bairro_cli = @_bairro, 
                        rua_cli = @_rua, 
                        numero_cli = @_numero,
                        id_plan_fk = @_idPlano
                    WHERE id_cli = @_id;
                ");

                comando.Parameters.AddWithValue("@_nome", cliente.NomeCliente);
                comando.Parameters.AddWithValue("@_telefone", cliente.Telefone);
                comando.Parameters.AddWithValue("@_cpf", cliente.CPF);
                comando.Parameters.AddWithValue("@_dataNasc", cliente.DataNascimento);
                comando.Parameters.AddWithValue("@_rg", cliente.RG);
                comando.Parameters.AddWithValue("@_estado", cliente.Estado);
                comando.Parameters.AddWithValue("@_cidade", cliente.Cidade);
                comando.Parameters.AddWithValue("@_bairro", cliente.Bairro);
                comando.Parameters.AddWithValue("@_rua", cliente.Rua);
                comando.Parameters.AddWithValue("@_numero", cliente.Numero);
                comando.Parameters.AddWithValue("@_idPlano", cliente.IdPlano);
                comando.Parameters.AddWithValue("@_id", cliente.IdCliente);

                comando.ExecuteNonQuery();
            }
            catch
            {
                throw;
            }
        }

        // --- EXCLUIR (DELETE) ---
        public void Excluir(int id)
        {
            try
            {
                var comando = _conexao.CreateCommand(
                    "DELETE FROM cliente WHERE id_cli = @id;"
                );

                comando.Parameters.AddWithValue("@id", id);

                comando.ExecuteNonQuery();
            }
            catch
            {
                throw;
            }
        }

        // --- LISTAR TODOS (READ All) - CORREÇÃO SQL APLICADA ---
        public List<Cliente> ListarTodos()
        {
            var lista = new List<Cliente>();
            
            // ✅ CORREÇÃO: Usando o nome correto da coluna do BD (p.nome_plan)
            // e o nome correto da FK (id_plan_fk e id_plan)
            var comando = _conexao.CreateCommand(@"
                SELECT 
                    c.*, 
                    p.nome_plan AS NomePlano
                FROM cliente c
                LEFT JOIN plano p ON c.id_plan_fk = p.id_plan;
            "); 
            
            var leitor = comando.ExecuteReader();

            while (leitor.Read())
            {
                var cliente = new Cliente
                {
                    IdCliente = leitor.GetInt32("id_cli"),
                    NomeCliente = DAOHelper.GetString(leitor, "nome_cli"),
                    Telefone = DAOHelper.GetString(leitor, "telefone_cli"),
                    CPF = DAOHelper.GetString(leitor, "cpf_cli"),
                    RG = DAOHelper.GetString(leitor, "rg_cli"),
                    Estado = DAOHelper.GetString(leitor, "estado_cli"),
                    Cidade = DAOHelper.GetString(leitor, "cidade_cli"),
                    Bairro = DAOHelper.GetString(leitor, "bairro_cli"),
                    Rua = DAOHelper.GetString(leitor, "rua_cli"),
                    Numero = DAOHelper.GetString(leitor, "numero_cli"),
                    
                    DataNascimento = leitor.IsDBNull(leitor.GetOrdinal("data_nasc_cli")) ? null : leitor.GetDateTime("data_nasc_cli"),
                    IdPlano = leitor.IsDBNull(leitor.GetOrdinal("id_plan_fk")) ? (int?)null : leitor.GetInt32("id_plan_fk"),
                    
                    // Mapeia o alias 'NomePlano' da query SQL para a propriedade NomePlano no C#
                    NomePlano = leitor.IsDBNull(leitor.GetOrdinal("NomePlano")) ? null : leitor.GetString("NomePlano")
                };

                lista.Add(cliente);
            }

            return lista;
        }
    }
}