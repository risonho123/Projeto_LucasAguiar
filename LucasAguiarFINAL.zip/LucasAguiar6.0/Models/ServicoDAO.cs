using LucasAguiar.Configs;
using MySqlConnector;
using AppWeb.Configs;

namespace LucasAguiar.Models
{
    public class ServicoDAO
    {
        private readonly Conexao _conexao;

        public ServicoDAO(Conexao conexao)
        {
            _conexao = conexao;
        }

        public void Inserir(Servico servico)
        {
            try
            {
                var comando = _conexao.CreateCommand( @"INSERT INTO servico (nome_serv, preco_serv, duracao_min, comis_funcionario_cli) VALUES (@_nome, @_preco, @_duracao, @_comissao)
                ");

                comando.Parameters.AddWithValue("@_nome", servico.NomeServico);
                comando.Parameters.AddWithValue("@_preco", servico.PrecoServico);
                comando.Parameters.AddWithValue("@_duracao", servico.DuracaoServico);
                comando.Parameters.AddWithValue("@_comissao", servico.ComissaoServico);
                comando.Parameters.AddWithValue("@_id", servico.IdServico);

                comando.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw new Exception("Erro ao inserir Serviço: "+ ex.Message);
            }
        }
        public Servico? BuscarPorId(int id)
        {
            var comando = _conexao.CreateCommand(
                "SELECT * FROM servico WHERE id_serv = @id;");
            comando.Parameters.AddWithValue("@id", id);

            var leitor = comando.ExecuteReader();

            if (leitor.Read())
            {
                var servico = new Servico();
                servico.IdServico = leitor.GetInt32("id_serv");
                servico.NomeServico = DAOHelper.GetString(leitor, "nome_serv");
                servico.PrecoServico = leitor.GetFloat("preco_serv");
                servico.DuracaoServico = leitor.GetInt32("duracao_min");
                servico.ComissaoServico = leitor.GetFloat("comis_funcionario_cli");

                return servico;
            }
            else
            {
                return null;
            }
        }
        public void Atualizar(Servico servico)
        {
            try
            {
                var comando = _conexao.CreateCommand(
                "UPDATE servico SET nome_serv = @_nome, preco_serv = @preco, duracao_min = @_durmin, comis_funcionario_cli = @_comis, WHERE id_serv = @_id ;");
                /*  id_serv int primary key auto_increment,
  nome_serv varchar(100),
  preco_serv float,
  duracao_min int,
  comis_funcionario_cli float
*/

                comando.Parameters.AddWithValue("@_nome", servico.NomeServico);
                comando.Parameters.AddWithValue("@preco", servico.PrecoServico);
                comando.Parameters.AddWithValue("@_durmin", servico.DuracaoServico);
                comando.Parameters.AddWithValue("@_comis", servico.ComissaoServico);

                comando.ExecuteNonQuery();
            }
            catch
            {
                throw;
            }
        }
        public void Excluir(int id)
        {
            try
            {
                var comando = _conexao.CreateCommand(
                "DELETE FROM servico WHERE id_serv = @id;");
                comando.Parameters.AddWithValue("@id", id);

                comando.ExecuteNonQuery();
            }
            catch
            {
                throw;
            }
            return;
        }

        public List<Servico> ListarTodos()
        {
            var lista = new List<Servico>();

            var comando = _conexao.CreateCommand("SELECT * FROM servico");
            var leitor = comando.ExecuteReader();

            while (leitor.Read())
            {
                var servico = new Servico
                {
                    IdServico =  leitor.GetInt32("id_serv"),
                    NomeServico = leitor.IsDBNull(leitor.GetOrdinal("nome_serv")) ? "" : leitor.GetString("nome_serv"),
                    PrecoServico = leitor.IsDBNull(leitor.GetOrdinal("preco_serv"))? 0f : leitor.GetFloat(leitor.GetOrdinal("preco_serv")),
                    DuracaoServico = leitor.GetInt32("duracao_min"),
                    ComissaoServico =  leitor.IsDBNull(leitor.GetOrdinal("comis_funcionario_cli"))? 0f : leitor.GetFloat(leitor.GetOrdinal("comis_funcionario_cli"))
            };

                lista.Add(servico);

            }
            return lista;
        }
    }
}